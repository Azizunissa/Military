// Role-based access control implementation
document.addEventListener('DOMContentLoaded', function() {
    // Get elements
    const roleSelector = document.querySelector('.role-selector');
    const roleBadge = document.getElementById('current-role-badge');
    const menuItems = document.querySelectorAll('.menu-item');
    const currentPage = window.location.pathname.split('/').pop().replace('.html', '').toLowerCase();

    // Set initial role from localStorage or default to admin
    let currentRole = localStorage.getItem('currentRole') || 'admin';
    roleSelector.value = currentRole;

    // Define role permissions
    const rolePermissions = {
        admin: ['dashboard', 'purchases', 'transfers', 'operations', 'predictions'],
        logistics: ['dashboard', 'purchases', 'transfers'],
        commander: ['dashboard', 'operations']
    };

    // Update menu items based on role
    function updateMenuForRole(role) {
        menuItems.forEach(item => {
            const pageName = item.textContent.trim().toLowerCase();
            item.classList.remove('active');
            
            // Highlight current page
            if (pageName === currentPage) {
                item.classList.add('active');
            }

            // Show/hide based on permissions
            if (rolePermissions[role].includes(pageName)) {
                item.style.display = 'block';
            } else {
                item.style.display = 'none';
            }
        });
    }

    // Check if current page is allowed for role
    function checkPageAccess() {
        const role = localStorage.getItem('currentRole') || 'admin';
        if (!rolePermissions[role].includes(currentPage)) {
            alert(`Access denied for ${role}. Redirecting to Dashboard.`);
            window.location.href = 'dashboard.html';
        }
    }

    // Initialize
    updateMenuForRole(currentRole);
    checkPageAccess();

    // Handle role changes
    roleSelector.addEventListener('change', function() {
        const newRole = this.value;
        localStorage.setItem('currentRole', newRole);
        roleBadge.textContent = this.options[this.selectedIndex].text;
        roleBadge.style.display = 'block';
        
        updateMenuForRole(newRole);
        
        setTimeout(() => {
            roleBadge.style.display = 'none';
            // Redirect to dashboard if current page not allowed
            if (!rolePermissions[newRole].includes(currentPage)) {
                window.location.href = 'dashboard.html';
            }
        }, 2000);
    });

    // Navigation handling
    menuItems.forEach(item => {
        item.addEventListener('click', function(e) {
            const pageName = this.textContent.trim().toLowerCase();
            const currentRole = localStorage.getItem('currentRole') || 'admin';
            
            // Check access
            if (!rolePermissions[currentRole].includes(pageName)) {
                e.preventDefault();
                alert(`Access denied for ${currentRole} role`);
                return;
            }
            
            if (pageName !== currentPage) {
                window.location.href = pageName + '.html';
            }
        });
    });
});